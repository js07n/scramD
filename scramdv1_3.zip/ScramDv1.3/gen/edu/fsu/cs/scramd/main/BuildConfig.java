/** Automatically generated file. DO NOT MODIFY */
package edu.fsu.cs.scramd.main;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}